# CLAUDE.md

This project uses `AGENTS.md` instead of a `CLAUDE.md` file.

Please see @AGENTS.md in this same directory and treat its content as the primary reference for this project.
